<?php
// 1か2をランダムに生成
$omikuji = rand(1, 2); 

if ($omikuji === 1) {
    echo "判定：大吉<br>";
    // <img>タグを出力。パスの指定に注意
    echo "<img src='picture/daikichi.png' width='150'>";
} else {
    echo "判定：小吉<br>";
    echo "<img src='picture/shokichi.png' width='150'>";
}
?>