<?php
$sei = isset($_POST['gender']) ? $_POST['gender'] : 3;
switch ($sei) {
    case 1: echo "男性ですね"; break;
    case 2: echo "女性ですね"; break;
    default: echo "未選択です"; break;
}
?>