<!DOCTYPE html>
<html lang="ja">
<head><meta charset="UTF-8"><title>受信</title></head>
<body>
<?php echo "入力された内容: " . $_POST['txt1']; ?>
</body>
</html>