<?php
$ary = ["a", "b", "c"];
$ary[] = "d"; // 末尾に追加
echo $ary[0]; // 0から始まる
?>