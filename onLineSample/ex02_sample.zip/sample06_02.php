<?php
$user = ["name" => "田中", "age"  => 25]; // キー => 値
echo $user["name"];   // キーを指定して表示
?>