<?php
$colors = ["red" => "赤", "blue" => "青"];
foreach ($colors as $key => $value) { // キーと値を取り出す
    echo "$key は日本語で $value です。<br>";
}
?>