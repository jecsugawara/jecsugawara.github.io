<?php
// 変数 = 条件 ? 真の場合 : 偽の場合;
$msg = empty($_POST['name']) ? "名無しさん" : $_POST['name'];
echo "こんにちは、" . $msg . "さん";
?>