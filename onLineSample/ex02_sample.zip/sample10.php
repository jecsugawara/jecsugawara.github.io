<?php // sample10.php
if (isset($_POST['hobby'])) {
    foreach ($_POST['hobby'] as $value) { 
        echo "趣味: $value <br>";
    }
}
?>