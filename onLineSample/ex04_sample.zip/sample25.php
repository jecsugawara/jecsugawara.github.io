<?php
require_once("db_connect.php");

$name = $_POST['u_name'];
$sql = "SELECT username, address FROM w_user WHERE username LIKE :target";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':target', '%' . $name . '%');
$stmt->execute();

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($results)) {
    echo "検索結果は見つかりませんでした。";
} else {
    foreach ($results as $row) {
        echo $row['username'] . "（" . $row['address'] . "）<br>";
    }
}
?>