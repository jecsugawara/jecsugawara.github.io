<?php
require_once("db_connect.php");

$sql = "SELECT id, username FROM w_user";
$stmt = $pdo->prepare($sql);
$stmt->execute();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo $row['id'] . "：" . $row['username'] . "<br>";
}
?>