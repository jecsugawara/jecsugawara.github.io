<?php
require_once("db_connect.php");
$id = $_GET['uid'];
$sql = "SELECT username, email FROM w_user WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row) {
    echo "名前：" . $row['username'] . "<br>";
    echo "Email：" . $row['email'];
} else {
    echo "指定されたユーザーは見つかりません。";
}
?>