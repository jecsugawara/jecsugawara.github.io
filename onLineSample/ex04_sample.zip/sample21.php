<?php
require_once("config.php");
echo "接続先ホスト: " . DB_HOST;
?>