<?php
require_once("db_connect.php");
echo "データベース接続に成功しました。";
?>