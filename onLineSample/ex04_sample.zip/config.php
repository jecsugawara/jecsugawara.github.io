<?php
// データベース接続情報の定義
define('DB_HOST', 'localhost');
define('DB_NAME', 'webdb');
define('DB_USER', 'dbuser');
define('DB_PASS', 'dbpass');
?>