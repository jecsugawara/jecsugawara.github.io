<?php
require_once("db_connect.php");

// 列名を明記して取得
$sql = "SELECT id, username, email FROM w_user WHERE id = 1";
$stmt = $pdo->prepare($sql);
$stmt->execute();

$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row) {
    echo "ID: " . $row['id'] . " 氏名: " . $row['username'];
}
?>